module.exports = {
  opus: require('./opus'),
  vorbis: require('./vorbis'),
  ...require('./core'),
};
